# AI-Anime 漫剧智能创作平台

> **AI 阅读说明**：本项目由 AI 驱动开发。**阅读顺序**：术语表 → 目标与原则 → 功能需求 → 领域模型 → 技术选型；**实现时**严格遵循原则、优先参考领域模型；**核心流程**：剧本 → 资产 → 脚本(审核) → 镜图(审核) → 镜头(审核) → 成片 → 导出。  
> **文档放置**：Rules（`.cursor/rules/`）、AGENTS（`AGENTS.md`）、工具说明（`docs/`）的职责与加载时机见 [docs/上下文工程/0.说明.md](docs/上下文工程/0.说明.md)。

## 目录

- [术语表](#术语表优先阅读)
- [产品概述](#产品概述)
- [开发原则](#开发原则ai-实现时须遵循)
- [需求列表](#需求列表)
- [技术选型](#技术选型实现参考)
- [验收标准](#6-验收标准实现完成后的检查清单)
- [运维与质量保障](#7-运维与质量保障)
- [目录设计](#目录设计)
  - [跨模块调用规则](#跨模块调用规则ai-须遵循)

---

## 术语表（优先阅读）

| 术语 | 含义 |
| ------ | ------ |
| 剧本 | 集-场-块结构的故事文本 |
| 资产 | 角色、场景、道具、风格等资源 |
| 脚本 | 结构化镜头指令列表（Shot Script） |
| 镜图 | 每个镜头的关键帧图像 |
| 镜头 | 每个镜头的视频片段 |
| 成片 | 最终导出的视频 |

---

## 产品概述

| 维度 | 内容 |
| ------ | ------ |
| **定位** | AI 驱动的漫剧创作平台，从故事到成片全流程覆盖 |
| **核心价值** | 全流程覆盖；资产统一管理；AI 深度集成（集级扩写、场级细化、块级补全、图像/视频生成、分镜生成）；模型灵活切换；结构化剧本（集-场-块） |
| **设计原则** | 流水线思维；资产优先；模型可配置；流程顺畅；效率优先；渐进加载 |

---

## 开发原则（AI 实现时须遵循）

### 架构与实现

| # | 原则 | 实现要求 |
| --- | ------ | ---------- |
| 1 | **架构优先** | 新功能前先搜索已有实现、工具类、模型；遵循现有目录与命名 |
| 2 | **领域模型先行** | 实现前须冻结领域模型；接口结构先于业务逻辑 |
| 3 | **资产引用** | 角色、场景等以 ID 引用，项目间不复制存储 |
| 4 | **模块独立** | 后端每模块：handler（接口）→ service（逻辑）→ data（存储）；单文件 ≤600 行 |
| 5 | **命名 AI 友好** | 文件/目录名语义化、模式一致，便于 AI 定位与生成。目录即上下文、利用目录表达类型、单文件优先渐进拆分；详见 [目录设计](#目录设计) |

### 代码质量

| # | 原则 | 实现要求 |
| --- | ------ | ---------- |
| 6 | **拒绝幻觉** | 不猜第三方 API；不确定时查源码或文档；不擅自改依赖版本 |
| 7 | **防御性编程** | 处理空值、超时、查询为空、无效输入；异常必记日志，不写空 catch；错误码见 [7.4 错误处理规范](#74-错误处理规范) |
| 8 | **安全** | 敏感信息走配置/环境变量；SQL 防注入；接口鉴权 |

### 漫剧生产特性

| # | 原则 | 实现要求 |
| --- | ------ | ---------- |
| 9 | **可追溯** | 镜图/镜头生成任务保留提示词、seed、模型等参数，支持复现 |
| 10 | **AI 接口语义化** | 若 API 供 AI 调用，名与描述明确「做什么」「何时用」；输出结构可解析 |
| 11 | **UI 三要素** | 组件（画什么）、动效（怎么变化）、状态（当前是什么） |

---

## 需求列表

### 1. 目标与原则（需求顶层约束）

#### 目标

1. **提高漫剧生产效率** — 从故事到成片全流程覆盖，数分钟完成短片
2. **沉淀无形资产** — 角色、场景、风格、提示词模板等可复用、可积累
3. **适合团队协作** — 多人分工、防冲突、通知同步

#### 原则（必须贯彻）

| # | 原则 | 含义 |
| --- | ------ | ------ |
| 1 | **AI 驱动** | 生产各环节由 AI 主导，人工负责审核与异常 |
| 2 | **任务编排** | 支持任务编排与定时任务 |
| 3 | **双线 AI** | 生产一条 AI 线，审核一条 AI 线，生成与审核分离 |
| 4 | **核心环节必须审核** | 脚本、镜图、镜头等核心产出必须经审核才能进入下一阶段 |
| 5 | **审核支持人工和 AI** | 每步可配置：人工审核 / AI 审核通过即继续 |
| 6 | **团队生产防冲突** | 支持团队协作，同一任务只能被一人执行，避免多人重复执行 |

---

### 2. 功能需求（按原则展开，实现时逐项满足）

#### 2.1 任务编排与定时（原则 2）

| 需求 | 描述 |
| ------ | ------ |
| 任务编排 | 支持工作流编排：从某阶段自动执行到成片，支持断点续跑 |
| 定时任务 | 支持按计划（如每日/每周）触发流水线或批量任务 |
| 任务锁 | 任务执行时自动加锁，他人不可重复执行同一任务 |

#### 2.2 双线 AI 与审核（原则 3、4、5）

| 需求 | 描述 |
| ------ | ------ |
| 生产 AI 线 | 脚本生成、镜图生成、镜头生成由生产 AI 完成 |
| 审核 AI 线 | 脚本 QA、镜图 QA、镜头 QA 由审核 AI 独立检查 |
| 核心环节审核 | 脚本、镜图、镜头必须审核通过才能进入下一阶段 |
| 审核方式可配置 | 每步可配置：仅人工 / 仅 AI / 人工+AI（AI 初筛+人工终审） |
| 不通过闭环 | 审核不通过 → 反馈给生产 AI → 修正 → 重试 |

#### 2.3 团队生产防冲突（原则 6）

| 需求 | 描述 |
| ------ | ------ |
| 执行即加锁 | 用户点击执行时自动加锁，流程无感 |
| 任务锁释放 | 完成/取消/超时后释放锁，他人可执行 |
| 冲突提示 | 他人执行中时，提示不可重复执行 |
| 可选增强 | 团队场景下可支持「认领」以明确责任人 |

#### 2.4 六阶段功能（原则 1：AI 驱动）

| 阶段 | 功能 | 说明 |
| ------ | ------ | ------ |
| **剧本** | 导入、编辑、锁定、集/场/块管理、AI 辅助 | 内容输入 |
| **资产** | 角色 CRUD、小传、形象生成、场景/道具/风格、版本 | 可沉淀、可复用 |
| **脚本** | 分镜生成、列表、预览、**审核** | 生产 AI 生成，审核 AI/人工审核 |
| **镜图** | 批量生成、**审核** | 同上 |
| **镜头** | 批量生成、**审核** | 同上 |
| **成片** | 时间线、音频/字幕、导出 | 合成输出 |

#### 2.5 支撑能力

| 需求 | 描述 |
| ------ | ------ |
| 项目 CRUD、仪表盘 | 项目管理 |
| 异步任务、WebSocket 进度 | 任务执行与实时反馈 |
| JWT 认证 | 用户认证 |
| 组织/团队 | 团队生产基础 |
| 文生图、文生视频、TTS | AI 能力 |

#### 2.6 任务通知（用户如何知道任务完成）

#### 最小实现

| 方式 | 场景 | 描述 |
| ------ | ------ | ------ |
| WebSocket 实时 | 用户在任务中心 | 进度条、状态变化实时更新，任务完成时 UI 立即刷新 |
| 站内通知中心 | 用户在其他页面 | 任务完成写入通知表，顶部/侧边栏红点 + 消息列表 |
| 红点/角标 | 全局 | 有未读通知时，导航栏显示未读数 |

#### 增强

| 方式 | 场景 | 描述 |
| ------ | ------ | ------ |
| 浏览器 Push | 用户切到其他标签/最小化 | 需用户授权，任务完成时推送系统级通知 |
| 声音/桌面提醒 | 任务完成时 | 可选播放提示音或系统通知 |

#### 2.7 生成物下载

| 需求 | 描述 |
| ------ | ------ |
| 单文件下载 | 镜图、镜头、成片、资产等生成物均可单独下载 |
| 按集打包下载 | 以集为单位打包（镜图/镜头/成片等），下载 ZIP |

---

### 3. 领域模型（数据结构与状态机，实现前须冻结）

#### 数据模型层级

```text
Project（项目）
  └── Episode（集）
        └── Scene（场）
              └── SceneBlock（内容块）
                    ├── action（动作描写）
                    ├── dialogue（台词）
                    ├── os（OS 旁白）
                    ├── direction（场景指示）
                    └── closeup（特写）
```

#### 数据流

```text
剧本(集-场-块) → 资产(角色/场景/道具) → 脚本 → 镜图 → 镜头 → 成片
```

#### 核心实体

| 分类 | 实体 |
| ------ | ------ |
| 剧本结构 | Project、Episode、Scene、SceneBlock |
| 资产 | Character、Asset、AssetVersion |
| 脚本/镜头 | Storyboard、Shot |
| 生成物 | ShotImage、ShotVideo |
| 成片 | CompositeTask |
| 用户与组织 | User、Organization、Team |
| 审核 | ReviewRecord |
| 通知 | Notification |
| 调度 | Schedule、Cron |

**实体补充说明**（对应需求与原则）：

| 实体 | 对应需求/原则 |
| ------ | ------ |
| User | 角色与权限、JWT 认证、任务锁执行人、公开注册 |
| Organization、Team | 目标「团队协作」、2.5「组织/团队」、2.3「团队生产防冲突」 |
| AssetVersion | 2.4 资产阶段「版本」、可沉淀可复用 |
| ReviewRecord | 2.2 审核闭环、状态机 review→approved/rejected、反馈给生产 AI |
| Notification | 2.6 站内通知中心、任务完成写入通知表、红点/角标 |
| Schedule、Cron | 2.1 定时任务、按计划（每日/每周）触发流水线 |

#### 状态机

| 阶段 | 状态 |
| ------ | ------ |
| 剧本 | draft → editing → locked |
| 脚本 | generated → editing → frozen |
| 镜图/镜头 | 见下文 |
| 成片 | editing → exporting → done |

**镜图/镜头状态机**（含不通过闭环与审核细化）：

```text
主流程：pending → generating → review → approved / rejected

不通过闭环：rejected → regenerating → review

进入下一阶段：approved → locked（锁定后不可修改）

审核状态细化（配置为 人工+AI 时）：
  review → ai_reviewing → ai_approved / ai_rejected
  ai_approved → approved
  ai_rejected → human_review → approved / rejected
```

#### 任务锁模型

任务（如「生成第 3 镜镜图」）有状态：待执行 / 执行中(执行人+时间) / 已完成 / 已取消。用户点击执行时自动加锁，同一任务同一时刻只能被一人执行。

---

### 4. 用户与部署（角色与权限参考）

| 角色 | 职责 |
| ------ | ------ |
| **导演** | 创意方向、分镜审定、最终审核（脚本/镜图/镜头全环节） |
| **分镜师** | 分镜脚本、镜头指令、与剧本/镜图联动、分镜审定（脚本阶段） |
| **设计师** | 角色设定、形象生成、场景、道具、风格资产、小传、参考包 |
| **原画师** | 镜图生成、镜图 |
| **镜头师** | 镜头视频生成、镜头 |
| **后期** | 成片剪辑、音频、字幕、导出 |
| **审核** | 各环节 QA 审核、批量审核、退回 |
| **平台管理员** | 用户、组织、任务配置、AI 配置 |

**多角色**：用户可拥有多个角色，权限取并集。小团队可一人兼任（如导演+审核），大团队可设专职审核。

**部署**：支持多规模部署（单机/集群），支持公开注册。

---

### 5. 非功能需求（实现时须满足）

| 类别 | 要求 |
| ------ | ------ |
| **性能** | 剧本渐进加载；任务进度 WebSocket <2s；列表分页 ≤50；布局自动适配 |
| **安全** | JWT；项目级鉴权；敏感信息配置/环境变量 |
| **可维护** | 模块独立；单文件 ≤600 行；异常必记日志 |
| **可扩展** | 多 AI Provider；Asynq + 状态机编排；定时任务调度 |

---

### 六、技术选型

| 层 | 技术 |
| ------ | ------ |
| **后端** | Go 1.25、Gin、PostgreSQL、sqlc、Redis+Asynq、S3 |
| **前端** | Flutter ^3.11、Riverpod、freezed、go_router、深色主题、布局自动适配 |
| **AI** | LLM/文生图/文生视频/TTS：DeepSeek、Flux、Runway、火山等 |

*详细技术栈见 [技术选型（实现参考）](#技术选型实现参考)。*

---

### 6.验收标准（实现完成后的检查清单）

- [ ] 目标达成：生产效率提升、资产可沉淀复用
- [ ] 原则落地：AI 驱动、任务编排、定时任务、双线 AI、核心环节审核、审核可人工/AI、团队防冲突
- [ ] 完整流程：导入剧本 → 资产 → 脚本(审核) → 镜图(审核) → 镜头(审核) → 成片 → 导出
- [ ] 任务锁：同一任务不同人不可同时执行
- [ ] 任务通知：WebSocket 实时 + 站内通知中心 + 红点；增强支持浏览器 Push、声音提醒
- [ ] 生成物下载：单文件可下载；支持按集打包下载（ZIP）
- [ ] 布局自动适配：Web 端在不同屏幕尺寸下正常显示
- [ ] 测试：核心 Service/API 有单元/集成测试；E2E 覆盖主流程
- [ ] 可观测性：Prometheus 指标、OpenTelemetry 追踪、Grafana 仪表盘
- [ ] AI 成本：用量统计、预算控制或告警

---

### 7. 运维与质量保障

#### 7.1 测试策略

| 类型 | 要求 | 说明 |
| ------ | ------ | ------ |
| **单元测试** | 核心 Service、Data 层覆盖 | Go: `go test`；关键业务逻辑、边界条件必测 |
| **集成测试** | API 端到端、数据库交互 | 使用测试库、Mock 外部 Provider；关键流程（登录、生成、审核） |
| **E2E 测试** | 核心用户路径 | Flutter 集成测试或 Playwright；剧本→资产→脚本→镜图→成片主流程 |
| **覆盖率** | 新增代码建议 ≥60% | CI 中可选执行覆盖率检查，不阻塞合并 |

#### 7.2 可观测性

| 组件 | 技术 | 说明 |
| ------ | ------ | ------ |
| **指标** | Prometheus + OpenTelemetry | 暴露 `/metrics`；记录请求延迟、错误率、AI 调用耗时 |
| **追踪** | OpenTelemetry Trace | 跨服务/跨 Provider 调用链；定位慢请求与失败根因 |
| **可视化** | Grafana | 仪表盘：API 延迟、任务队列堆积、AI 调用量/成本 |
| **告警** | Prometheus Alertmanager | 错误率突增、队列积压、AI 调用异常 |

AI 任务量大，不监控成本与延迟存在生产风险，可观测性为必选项。

#### 7.3 AI 成本控制

| 能力 | 说明 |
| ------ | ------ |
| **用量统计** | 按 Provider、模型、项目/用户记录 token 数、图片数、视频秒数 |
| **预算控制** | 项目级/组织级预算上限；超限时拒绝新任务或告警 |
| **告警** | 日/周用量超阈值、单次调用异常高成本时通知 |
| **实体** | ProviderUsage、CostLog（可选，见领域模型补充说明） |

多 Provider 无预算控制易导致生产环境意外账单，上线前须具备基础用量统计与告警。

#### 7.4 错误处理规范

| 要求 | 说明 |
| ------ | ------ |
| **统一错误码** | 业务错误使用 `ERR_XXX` 格式（如 `ERR_PROJECT_NOT_FOUND`）；HTTP 映射到 4xx/5xx |
| **错误透传** | 不吞异常；Handler 层统一包装为 `{code, message, details?}` 返回前端 |
| **日志** | 错误必记 zap 日志，含 request_id、用户、上下文 |
| **防御性编程** | 见开发原则 #7 |

#### 7.5 缓存策略

| 场景 | 策略 | 说明 |
| ------ | ------ | ------ |
| **任务队列** | Redis + Asynq | 异步任务（图片/视频/TTS 等） |
| **热点数据** | Redis 缓存 | 项目列表、资产元数据、用户会话；TTL 按业务设置（如 5–60 分钟） |
| **缓存失效** | 写时失效 | 项目/资产更新时删除或更新对应 key |
| **冷启动** | 可接受短暂穿透 | 非强一致性场景允许缓存未命中时查库 |

#### 7.6 文件清理策略

| 场景 | 策略 | 说明 |
| ------ | ------ | ------ |
| **生成失败** | 任务失败后清理中间产物 | Worker 失败时删除临时文件；或定时任务扫描失败任务关联文件 |
| **过期任务** | 保留期后清理 | 如已完成任务关联的中间文件保留 N 天（可配置）后删除 |
| **孤立文件** | 定时扫描 | 定期比对存储与数据库，删除无引用的文件 |
| **配置** | 清理策略可配置 | 保留天数、是否启用清理等通过配置控制 |

---

## 技术选型（实现参考）

### 后端 (anime-ai)

| 类别 | 技术 | 说明 |
| ------ | ------ | ------ |
| **语言** | Go 1.26 | |
| **Web 框架** | Gin | HTTP API、路由、中间件 |
| **数据库** | PostgreSQL | 关系型、JSONB、全文检索 |
| **ORM** | sqlc | SQL 先行、类型安全代码生成、Atlas 版本化迁移 |
| **缓存 / 任务队列** | Redis + Asynq | 异步任务；热点数据缓存（项目列表、资产）；策略见 [7.5 缓存策略](#75-缓存策略) |
| **认证** | JWT (golang-jwt/jwt/v5) | Token 鉴权 |
| **配置** | Viper + YAML | 支持环境变量覆盖 (APP_*) |
| **日志** | zap | 结构化日志 |
| **实时通信** | WebSocket (gorilla/websocket) | 任务进度、协作实时推送 |
| **存储** | 对象存储 (S3 兼容) | OSS/MinIO 等，上传与生成文件 |
| **工作流** | Asynq + 状态机 | 长流程编排（一键出片等）；任务链 + 状态持久化实现断点续跑、重试 |
| **可观测性** | OpenTelemetry、Prometheus、Grafana | 指标、追踪、仪表盘；见 [7.2 可观测性](#72-可观测性) |

#### 工程与部署

| 类别 | 技术 | 说明 |
| ------ | ------ | ------ |
| **CI/CD** | GitHub Actions / GitLab CI | 构建、测试、部署自动化 |
| **容器** | Docker Compose | 统一开发环境 |

#### AI 能力与 Provider

| 能力 | Provider | 说明 |
| ------ | ---------- | ------ |
| **LLM** | DeepSeek, Kimi, Doubao, Aliyun | OpenAI 兼容接口 |
| **文生图** | Seedream, Wanx, CogView, Flux, Stability | |
| **文生视频** | Runway, Seedance, Kling, CogVideo | |
| **TTS** | 火山引擎, CosyVoice, Fish Audio, MiniMax | |
| **音乐** | Suno | |
| **KIE** | 视频/图片理解 | 多模态理解 |

#### 后端架构

- **Handler**：HTTP 接口层
- **Service**：业务逻辑层
- **Data**：数据访问层（封装 sqlc Queries）
- **Provider**：AI 服务适配器（LLM/Image/Video/TTS/Music）
- **Mesh**：能力路由、熔断、重试、限流
- **Worker**：Asynq 异步任务处理
- **Realtime**：WebSocket Hub 与房间管理

---

### 前端 (anime-ui)

| 类别 | 技术 | 说明 |
| ------ | ------ | ------ |
| **框架** | Flutter ^3.11.0 | 跨平台（Web/桌面） |
| **路由** | go_router | |
| **状态管理** | flutter_riverpod | |
| **HTTP** | dio | API 请求 |
| **实时** | web_socket_channel | WebSocket 连接 |
| **数据模型** | freezed + json_serializable | 不可变模型、JSON 序列化 |
| **树形导航** | flutter_fancy_tree_view | 集-场-块树形展示 |
| **块编辑器** | 自定义 Block Editor | 非 flutter_quill，ReorderableListView + 类型化 TextField |
| **UI** | flutter_markdown, just_audio, solar_icons | 深色主题、紫色强调、布局自动适配 |

---

### 开发与部署（启动命令）

| 操作 | 命令 |
| ------ | ------ |
| 后端启动 | `cd anime_ai && go run .` 或 `air`，端口 3737 |
| 前端启动 | `flutter run -d web-server --web-port 8080 --dart-define=API_BASE_URL=http://localhost:3737/api/v1` |
| Redis | `redis-server --daemonize yes`（异步任务依赖） |
| 一键启停 | `r.sh` 启动 / `s.sh` 停止 |
| 默认管理员 | admin / admin123 |

**常用命令**：后端 `anime_ai/Makefile`（run、build、test、tidy）；Flutter 修改 freezed/json_serializable 模型后运行 `dart run build_runner build --delete-conflicting-outputs`。

**环境要求**：Go 1.26+；Flutter SDK ^3.11.0。

## 目录设计

### 目录设计原则（AI 与团队须遵循）

| 原则 | 说明 |
| ------ | ------ |
| **模块化 + 公共层** | 业务按领域拆成 `module/`，基础设施放 `pub/`；入口 `main`、`route` 放根目录 |
| **目录即上下文** | 目录已表达类型时，文件名不重复层名（如 `providers/character_list.dart` 而非 `character_list_provider.dart`）；AI 通过路径即可定位 |
| **渐进式拆分** | 单文件优先，量大时再分子目录；同一层超 2–3 个文件或单文件近 600 行时拆分 |
| **单一职责** | 一个文件尽量只包含一个主要类（如 `CharacterList`） |
| **利用目录** | Provider 放 `providers/`，组件放 `widgets/`，页面放 `page/`，不在文件名后加后缀 |
| **后缀例外** | 仅在可能歧义时用后缀（如 `character_list_screen.dart` 与 `character_list_logic.dart` 区分 UI 与逻辑） |
| **view → page** | 前端模块用 `page/` 承载页面，不用 `view/` |
| **Handler → Service → Data** | 后端三层：Handler 对外接口、Service 业务逻辑、Data 数据访问 |
| **资源_层（pub 内）** | pub 内跨模块文件用 `资源_层`（如 `shot_image_service.go`、`project_provider.dart`），便于按业务检索 |
| **单文件 ≤600 行** | 超限则拆分子文件或子模块 |
| **命名语义化** | 避免 `s1.go`、`util2.dart`，用可读、可搜索的名称 |

### 跨模块调用规则（AI 须遵循）

| 规则 | 说明 |
| ------ | ------ |
| **相同层级模块可相互依赖** | `module/` 下同级模块（如 script、assets、shots）之间可相互引用；同一父模块下的子目录（如 assets/characters、assets/locations）之间亦可相互引用 |
| **模块间禁止直接引用 Data** | `module/shot_image/` 的 Service **不得**直接调用 `module/character/` 的 Data；跨模块访问应通过对方模块的 Service 或接口 |
| **通过接口解耦（可选）** | 需要灵活切换实现时，跨模块依赖可通过接口定义，由调用方注入或由 pub 编排层提供实现 |
| **pub 提供跨模块编排** | 需要组合多模块能力的场景，在 `pub/` 中实现编排服务（如 `pub/shot_image_service.go` 编排 shot_image + character）；编排服务可注入各模块的 Service 或 Data 接口 |
| **sch 提供跨模块数据模型** | 共享实体、DTO、sqlc schema、SQL 查询等放在 `sch/`，模块与 pub 均可引用；避免模块间互相引用对方的数据结构 |
| **依赖方向** | `module → pub`、`module → sch` 允许；**相同层级** `module` 之间可相互依赖；跨层级或跨领域时建议经 pub 或接口 |

**示例**：镜图生成需角色信息时，`module/shot_image/service.go` 可调用 `module/character/service.go` 的公开方法，但不得直接 import `module/character/data.go`；若需解耦，可依赖注入 `CharacterReader` 接口，由 `pub/` 编排层注入实现。

---

项目采用 monorepo 布局，后端与前端分仓同根，便于统一构建与部署。

### 仓库根目录

```text
anime/
├── anime_ai/         # Go 后端
├── anime_ui/         # Flutter 前端
├── deploy_packages/  # 部署脚本与说明
├── build_deploy.sh   # 构建 Debian 部署包
├── r.sh              # 本地启动前后端
├── docker-compose.yml
└── README.md
```

---

### 后端 (anime_ai)

后端目录名为 `anime_ai`，采用「模块化 + 公共层」布局：`main → route → module → pub → sch`。

遵循 Handler → Service → Data 分层，单文件 ≤600 行。

```text
anime_ai/
├── main.go               # 程序入口
├── route.go              # HTTP 路由注册（集中调用各模块 Register）
├── module/               # 业务模块（按领域拆包，模块内 handler/service/data）
│   ├── auth/             # 认证
│   ├── project/           # 项目管理
│   ├── character/         # 角色资产
│   ├── shot/              # 镜头
│   ├── storyboard/        # 分镜
│   ├── script/            # 脚本
│   └── ...
├── pub/                  # 公共基础设施
│   ├── config/           # 配置加载
│   ├── middleware/       # 鉴权、CORS、日志、限流
│   ├── auth/             # RBAC、上下文
│   ├── pkg/              # 通用工具（errs、jwt、resp、hash、ffmpeg）
│   ├── storage/          # 文件存储抽象
│   ├── realtime/         # WebSocket Hub、房间管理
│   ├── worker/            # Asynq 异步任务
│   ├── tasktypes/         # 任务类型定义
│   ├── mesh/             # AI 能力路由、熔断、重试、限流
│   ├── capability/       # AI 能力接口
│   ├── adapters/         # 第三方适配（openai、volc）
│   ├── controlplane/     # 特性开关、模型目录、路由策略
│   └── provider/         # AI Provider 实现
│       ├── llm/
│       ├── image/
│       ├── video/
│       ├── audio/
│       ├── music/
│       └── kie/
├── sch/                  # sqlc schema、SQL 查询定义
├── migration/            # 数据库迁移
├── workspace/            # 环境配置与文档
│   ├── config/           # 多环境配置
│   └── doc/              # 文档
├── config.yaml.example
├── feature_flags.yaml
├── route_policy.yaml
├── Makefile
└── Dockerfile
```

**目录说明**：`module`=业务模块、`pub`=公共层、`sch`=Schema、`workspace`=环境与文档；入口 `main.go`、`route.go` 放根目录。

**模块内部**：每个 module 子目录内统一用层名文件，目录即上下文，无需资源前缀：

```text
module/shot_image/
├── handler.go    # 镜图 HTTP 接口
├── service.go    # 镜图业务逻辑
└── data.go       # 镜图数据访问
```

---

### 前端 (anime_ui)

采用与后端一致的「模块化 + 公共层」布局：`main → route → module → pub`。

```text
anime_ui/
├── lib/
│   ├── main.dart             # 程序入口
│   ├── route.dart            # 路由配置（集中注册）
│   ├── module/               # 业务模块（按领域）
│   │   ├── login/            # 登录
│   │   ├── project/          # 项目管理
│   │   ├── dashboard/        # 仪表盘
│   │   ├── draft/            # 剧本草稿
│   │   ├── episode/          # 集
│   │   ├── edit/             # 剧本编辑
│   │   ├── story/            # 故事
│   │   ├── script/           # 脚本（分镜指令）
│   │   ├── storyboard/       # 分镜板
│   │   ├── shot_images/      # 镜图
│   │   ├── shots/            # 镜头
│   │   ├── board/            # 画板
│   │   ├── generate/         # 生成入口
│   │   ├── task_center/      # 任务中心
│   │   ├── assets/           # 资产（角色/场景/道具/资源/风格）
│   │   │   ├── characters/
│   │   │   ├── locations/
│   │   │   ├── props/
│   │   │   ├── resources/
│   │   │   └── overview/
│   │   ├── layout/           # 布局
│   │   └── config/           # 配置
│   └── pub/                  # 公共层
│       ├── const/            # 常量
│       ├── router/           # go_router 配置
│       ├── theme/            # 主题、颜色
│       ├── utils/            # 工具函数
│       ├── widgets/          # 通用与共享组件（按钮、表单、生成中心、图生、文生、语音、审核布局等）
│       ├── models/           # 数据模型
│       ├── data/             # 数据层
│       ├── providers/        # Riverpod Provider
│       ├── services/         # API 调用
│       └── ai/               # AI 相关（模型、服务、组件）
├── assets/
└── pubspec.yaml
```

**目录说明**：`module`=业务模块、`pub`=公共层；入口 `main.dart`、`route.dart` 放 lib 根目录。

**模块内部**：遵循渐进式拆分，单文件能承载时直接用，量大再分子目录。目录即上下文，文件名不重复层名。

*简单模块*（单文件即可）：

```text
module/login/
├── provider.dart    # 单一 Provider，单文件承载
├── page.dart        # 单一页面
└── index.dart      # 对外导出
```

*复杂模块*（某层文件多时拆子目录）：

```text
module/shot_images/
├── providers/           # Provider 多时拆目录
│   ├── shot_list.dart   # 目录已表达 provider，文件名只写业务
│   └── shot_detail.dart
├── widgets/             # 组件多时拆目录
│   └── shot_card.dart   # 一文件一主类（ShotCard）
└── page/                # 页面多时拆目录
    └── list.dart        # 或 list_page.dart（仅歧义时加后缀）
```

**前端模块组织细则**（AI 与团队须遵循）：

| 细则 | 说明 |
| ------ | ------ |
| **单一职责** | 一个文件尽量只包含一个主要类（如 `CharacterList`、`ShotCard`） |
| **利用目录** | 将功能类似的 Provider 放入 `providers/`，类似组件放入 `widgets/`，而非在每个文件名后都加 `_provider`、`_widget` 等后缀 |
| **后缀例外** | 仅在可能引起歧义时使用后缀，如 `character_list_screen.dart` 与 `character_list_logic.dart` 以区分 UI 与逻辑 |
| **pub 与 module 差异** | module 子目录=业务资源+层（`character/providers/`）；pub 子目录=能力类型（`router/`、`widgets/`、`providers/`），其下跨模块文件用 `资源_层` 便于检索 |

---

### 命名约定（AI 友好）

| 层级 | 约定 | 示例 |
| ------ | ------ | ------ |
| 后端模块内 | 层名文件，目录即资源 | `handler.go`、`service.go`、`data.go` |
| 后端 pub 内 | 资源_层，便于按业务检索 | `character_data.go`、`shot_image_service.go` |
| 前端模块内（简单） | 单文件，层名即文件名 | `provider.dart`、`page.dart` |
| 前端模块内（复杂） | 层名子目录 + 文件名不重复层名 | `providers/character_list.dart`、`widgets/shot_card.dart` |
| 前端模块内（歧义时） | 后缀区分 UI/逻辑 | `character_list_screen.dart`、`character_list_logic.dart` |
| 前端 pub 内 | 跨模块用 资源_层；组件用 PascalCase | `character_list_provider.dart`、`ShotImageCard` |
